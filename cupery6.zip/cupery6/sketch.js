let value = 100;
let x = [];
let tenVals = [];
let def = [1, 2, 5, 6, 10, 12];

function setup() {
  createCanvas(600, 400);
  print(def.length);
  for(let i = 0; i < 100; i++){
    x[i] = 0;
  }
}

function draw() {
  background(0);
  for(let i = value-1; i > 0; i--){
    x[i] = x[i-1];
  }
  for(let i = 1; i < value; i++){
    tenVals[i] = i * 10;
  }
  x[0] = mouseX;
  tenVals[0] = mouseY;
  for(let i = 0; i < 100; i++){
    fill(i * 2);
    ellipse(x[i], tenVals[i], tenVals[i]);
  }
}