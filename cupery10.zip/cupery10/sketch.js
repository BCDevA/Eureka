let cycle = 3;
let seedX = Math.random();
let seedY = Math.random();
function setup() {
  createCanvas(400, 400);
  background(0);
  if(cycle === 1){
    createLoop();
  }else if(cycle === 2){
    createLoop({noiseFrequency:10, noiseSeed:2})
  }else{
    createLoop(10, {noiseFrequency:1})
  }
}

function draw() {
  if(cycle === 1){
    translate(width / 2, height / 2)
    const radius = height / 3
    const x = cos(animLoop.theta) * radius
    const y = sin(animLoop.theta) * radius
    ellipse(x, y, 50, 50)
  }else if(cycle === 2){
    translate(width / 2, height / 2)
    const radius = height / 3
    const x = cos(animLoop.theta) * width/4
    const y = animLoop.noise() * height/2
    ellipse(x, y, 50, 50)
  }else{
    translate(width / 2, height / 2)
    const radius = height / 3
    const x = animLoop.noise({seed:seedX}) * width/3
    const y = animLoop.noise({seed:seedY}) * height/2
    ellipse(x, y, 50, 50)
  }
}