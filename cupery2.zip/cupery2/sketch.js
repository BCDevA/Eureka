function setup() {
  //Establish the base frame in setup()
  
  //createCanvas(W, H)
  createCanvas(400, 400);
  
  //background(COLOR)
  background(25);
}

function draw() {
  //Input code for shapes in draw()
  
  //colorMode(COLORCHANNELS, RANGE1, RANGE2, RANGE3, [ALPHA])
  colorMode(RGB, 255, 255, 255, 1);
  
  //fill(VALUE1, VALUE2, VALUE3, [ALPHA])
  fill(255, 125, 5, 0.5);
  
  //stroke(VALUE1, VALUE2, VALUE3, [ALPHA])
  stroke(250, 190, 30, 0.2);
  
  //strokeWeight(WEIGHT)
  strokeWeight(50);
  
  //ellipse(X, Y, W, [H])
  ellipse(200, 0, 300);
  
  strokeWeight(1);
  stroke(255, 255, 255, 0.05);
  noFill();
  
  //bezier(X1, Y1, X2, Y2, X3, Y3, X4, Y4)
  bezier(0, 100, 0, 250, 400, 250, 400, 100);
  bezier(0, 200, 0, 325, 400, 325, 400, 200);
  bezier(0, 300, 0, 425, 400, 425, 400, 300);
  
  strokeWeight(0);
  fill(230, 240, 30)
  ellipse(50, 180, 75)
  
  fill(25);
  //arc(X, Y, W, H, START, STOP);
  arc(50, 190, 80, 80, TWO_PI + HALF_PI + PI/8, TWO_PI + PI)
  
  strokeWeight(2);
  fill(2, 140, 230, 0.8);
  ellipse(300, 280, 55)
  
  strokeWeight(1);
  stroke(1, 55, 125);
  fill(120, 90, 60);
  //beginShape([KIND])
  beginShape();
    //vertex(X, Y)
    vertex(282, 262);
    vertex(322, 264);
    vertex(310, 285);
    vertex(287, 300);
    vertex(287, 286);
  //endShape([MODE])
  endShape(CLOSE)
  
  strokeWeight(5);
  stroke(180, 145, 175, 1);
  fill(195, 100, 4, 0.2);
  ellipse(200, 390, 150)
  
  strokeWeight(0);
  fill(125, 0, 0, 0.6);
  ellipse(200, 390, 50, 20);
}